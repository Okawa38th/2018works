package part1;
import java.util.Scanner;
public class TheGlobalDistanceCalculator {
    public  static void main(String[] args){
        System.out.println("***Welcome to  DACHUAN's Distance Calculator***" + '\n'
               + "Enter Data for the Starting City" );
        Scanner a = new Scanner (System.in);
        System.out.println("Name :" );
        String sn = a.nextLine();
        System.out.println("Latitude Degrees:");
        int slad = a.nextInt();
        System.out.println("Latitude Minutes:");
        int slam = a.nextInt();
        System.out.println("Latitude Seconds:");
        int slas = a.nextInt();
        System.out.println("Longitude Degrees:");
        int slod = a.nextInt();
        System.out.println("Longitude Minutes:");
        int slom = a.nextInt();
        System.out.println("Longitude Seconds:");
        int slos = a.nextInt();
        Scanner b = new Scanner (System.in);
        System.out.println("Enter Data for the Destination City" );
        System.out.println("Name: ");
        String dn = b.nextLine();
        System.out.println("Latitude Degrees:");
        int dlad = b.nextInt();
        System.out.println("Latitude Minutes:");
        int dlam = b.nextInt();
        System.out.println("Latitude Seconds:");
        int dlas = b.nextInt();
        System.out.println("Longitude Degrees:");
        int dlod = b.nextInt();
        System.out.println("Longitude Minutes:");
        int dlom = b.nextInt();
        System.out.println("Longitude Seconds:");
        int dlos = b.nextInt();

        double sla = slad + (slam/60) + (slas/3600);
        double slo = slod + (slom/60) + (slos/3600);
        double dla = dlad + (dlam/60) + (dlas/3600);
        double dlo = dlod + (dlom/60) + (dlos/3600);
        double x = (Math.sin(sla/(180/Math.PI))* Math.sin(dla/(180/Math.PI))
                + ((Math.cos(sla/(180/Math.PI)))* (Math.cos(dla/(180/Math.PI)))
                * (Math.cos(dlo/(180/Math.PI) - (slo/(180/Math.PI))))));
        double distance = 6371 * Math.atan(Math.sqrt((1-Math.pow(x,2)))/x);
        System.out.println("Enter Data for the Starting City:" + '\n'+
                '\t'+ "Name: " + sn + '\n' + '\t'+
                "Latitude Degrees: " + slad + '\n' + '\t'+
                "Latitude Minutes: " + slam + '\n' + '\t'+
                "Latitude Seconds: " + slas + '\n' + '\t'+
                "Longitude Degrees: " + slod + '\n'+ '\t'+
                "Longitude Minutes: " + slom + '\n'+ '\t'+
                "Longitude Seconds: " + slos + '\n'+
                "Enter Data for the Destination City: " + '\n'+
                        '\t'+ "Name: " + dn + '\n' + '\t'+
                        "Latitude Degrees: " + dlad + '\n' + '\t'+
                        "Latitude Minutes: " + dlam + '\n' + '\t'+
                        "Latitude Seconds: " + dlas + '\n' + '\t'+
                        "Longitude Degrees: " + dlod + '\n'+ '\t'+
                        "Longitude Minutes: " + dlom + '\n'+ '\t'+
                        "Longitude Seconds: " + dlos + '\n' +
                sn +" is " + distance + " kilometers from " + dn );
    }
}
