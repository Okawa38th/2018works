package part2;
import java.util.Scanner;
public class GeographicCoordinatesExtractor {
    public static void main(String[] args){
        System.out.println("*** WELCOME TO Dachuan He's GEOGRAPHIC COORDINATES EXTRACTOR ***");
        System.out.println("Enter Geographic Coordinates:");
        Scanner in = new Scanner(System.in);
        String geo = in.nextLine();
        String fuhao = "\u00b0,\',\", ";
        String[] fuhaos = fuhao.split(",");
        String[] geos = geo.split(" ");
        for(int y=0;y<=3;y++){
            System.out.print(geos[y]+fuhaos[y]+'\n');
        }


    }
}
